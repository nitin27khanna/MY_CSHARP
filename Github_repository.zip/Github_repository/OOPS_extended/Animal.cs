// inheritence can be defined by is-a relationship
//aggregation can be defined by has-a relationship . basically when a class type is used in another as an object


using System;

namespace OOPS_extended
{
    class Animal
    {
        private string name;
        protected string sound;

        public void MakeSound()
        {
            Console.WriteLine($"{Name} makes {Sound}");
        }

//Constructors
        //empty constructor
        public Animal()
        :this("No name","No Sound") {}


        //1 var passed 
        public Animal(string name):this(name , "No Sound")  {        }
    
        //both var passed
//        public Animal (string name , string sound):this(name,sound) {}
//other way
    public Animal(string name , string sound){
            Name = name;
            Sound = sound;
    }


        public  string Name 
        {
            //getter and setter properties
            get {return name;}
            set {
                if  (value.Length > 15 )
                    name = "No Name";
                else 
                    name = value;
                }
        }

        
        public  string Sound 
        {
            //getter and setter properties
            get {return sound;}
            set {
                if  (value.Length > 20)
                    sound = "No Sound";
                else 
                    sound = value;
                }
        }
    }

//inherited . multiple class inheritence not allowed 
    class Dog : Animal
    {
        private string sound2;
        public string Sound2 {get;set;} = "Grrrrr";

        //override makesound
        public new void MakeSound()
        {
            Console.WriteLine($"{Name} says {Sound} and {Sound2}");
        }

        //constructor
        public Dog (string name = "No name" , string sound = "No sound" , string sound2 = "No Sound2")
        :base(name , sound)
        {
            Sound2 = sound2;
        }
    }




}