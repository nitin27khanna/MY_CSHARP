﻿using System;

namespace OOPS_extended
{
    class Program
    {
        static void Main(string[] args)
        {
           Animal a1 = new Animal()
           {
            Name="Whiskers",
            Sound = "Meow",
           };

           Dog d1 = new Dog()
           {
               Name ="Grover",
               Sound = "Woof",
               Sound2 = "Grrrr",
           };

        d1.Sound2 = "Wooof";
        d1.MakeSound();
        a1.MakeSound();

            Console.WriteLine("");
        }
    }
}
