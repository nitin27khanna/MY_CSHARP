﻿//Program : Basics part III
//Relational operators , control statements
using System;

namespace basicsRelationalcontrol
{
    class Program
    {
        static void Main(string[] args)
        {
            int age = 17;

            if (age < 15) {
                Console.WriteLine("Go to School");
            }else if (age  >= 15 && age <=19)
            {
                Console.WriteLine("Go to High School");
            }else 
            {
                Console.WriteLine("Go to College");
            }

            switch(age){
                case 13: Console.WriteLine("High");break;
                case 17 : Console.WriteLine("Low");break;
                default: Console.WriteLine("Out of inputs");goto Outofswitch;
            }

            Outofswitch:
            Console.WriteLine("Hi Im out");
            string name = "Nitin";
            string name2 = "nitin";

            if(name.Equals(name2,StringComparison.OrdinalIgnoreCase))
                Console.WriteLine("Names equal");


        ///random function play
        Random rnd = new Random ();
        int secretNumber  = rnd.Next(1,10) ;
        int guessedNumber = 0;
        do {
            Console.Write("Enter the number : ");
            guessedNumber = Convert.ToInt32(Console.ReadLine()); 
        }while(secretNumber != guessedNumber);
        //other convert types are ToBoolean,ToByte etc
        
        //exception
        double d = 5;

       /* try {
            Console.WriteLine("{0}/5 : {1}",d,Divi(d,5));
        }*/

        try {
            Console.WriteLine("{0}/0 : {1}",d,Divi(d,5));
        } 
         
         catch (DivideByZeroException ex)
         {
             Console.WriteLine("Cant divide numbers by 0");
             Console.WriteLine(ex.GetType().Name);
         }
         catch(Exception ex){
             Console.WriteLine("Attempting Voilations");
         }
         finally{
             Console.WriteLine("Cleaning Up");
         }
        }
        static double Divi(double d , double d1){
            if(d1 == 0){
                throw new System.DivideByZeroException();
            }
            else 
            return d/d1;
        }
    }
}
