﻿using System;
using System.Collections;
using System.Linq;
using System.Collections.Generic;


namespace collectionGenerics
{
    class Program
    {
        static void Main(string[] args)
        {
            List<Animal> animalList = new  List<Animal>();

            animalList.Add(new Animal(){Name = "Tommy"});
            animalList.Add(new Animal(){Name = "Bruno"});
            animalList.Add(new Animal(){Name = "Tika"});
            animalList.Add(new Animal(){Name = "TinTin"});
            
            foreach (Animal a in animalList)
                Console.WriteLine($"Animal : Name :{a.Name}");
            
            animalList.Insert(1,new Animal(){Name = "Breena"});
            foreach (Animal a in animalList)
                Console.WriteLine($"Animal : Name :{a.Name}");
            
            animalList.RemoveAt(2);

            Console.WriteLine($"Number OF animals # {animalList.Count}");

            foreach (Animal a in animalList)
                Console.WriteLine($"Animal : Name :{a.Name}");

            GetSum(4,5.01);


              // Generics ...Stack<T> , Queue<T> , Dictionary<Tkey , Tvalue>  
            //List<int> numList = new List<int>();
            //Console.WriteLine("Hello World!");
            genRec<int> rectan = new genRec<int>(10,10);
            Console.WriteLine(rectan.area());
        
        }

        public static void  GetSum <T> (T num1 , T num2)
        {
            Console.WriteLine($"{num1} + {num2} = {(Convert.ToDouble(num1)+Convert.ToDouble(num2))}");
        }
        public struct genRec <T>
        {
            private T len;
            private T width;
            public genRec(T len, T width)
            {
                 this.len = len;
                 this.width = width;
            }
            public T Len {
                get
                {
                  return len;
                     }
                set{
                    len = value;
                    }
                }
            public T Width {
                get{return width;}
                set {width = value;}

            } 
            public string area()
              {
                  return string.Format($"{Len} * {Width} = {Convert.ToDouble(len) * Convert.ToDouble(width)}");
              }
        }
  
  
    }

}
