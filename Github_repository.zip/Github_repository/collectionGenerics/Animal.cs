using System;

namespace collectionGenerics
{
 class Animal
 {
     public string Name {get ; set; }

     public Animal(string name = "No name")
     {
         Name = name;
     }
 }
}