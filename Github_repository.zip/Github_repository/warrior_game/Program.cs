﻿using System;

namespace warrior_game
{
    class Program
    {
        static void Main(string[] args)
        {
            warrior maximus = new warrior("maximus",500,100 , 50);
            
            warrior wolverine = new warrior("wolverine",400,90 , 60);
            
            battle b1 = new battle(maximus,wolverine);
                    }
    }
}
