//warrior class 
//makes warrior with certain objects
 
 using System;

 namespace warrior_game
 {
     class  warrior {
         //declare variables for name , health , attack , block
         private string name;
         private int health;
         private int attack;

         private int block;
         
         //constructor 
         public warrior (string name ="No name" ,int health = 0, int attack = 0 , int block = 0 )
           {
               this.name = name;
               this.health = health;
               this.attack = attack;
               this.block = block;
           }    
          public void comments()
          {
              Console.WriteLine($"{name} attacks with {attack}");
          }

          public void update_health(int attacked_by)
            {
                   this.health = this.health - attacked_by + this.block; 
                }

          public int Health {
              get {return health;}
              set {health = value;}
          }
          public int Attack {
              get {return attack;}
              set {attack = value;}
          }
          public string Name {
              get {return name;}
              set {name = value;}
          }
        }
 }