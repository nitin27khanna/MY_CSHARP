//battle class to start the original battle
//will follow aggregation model
using System;

namespace warrior_game{

class battle 
{
    private warrior w1;
    private warrior w2; 

    public battle(warrior w1 , warrior w2)
        {
            while(w1.Health > 0 && w2.Health > 0 )
                {
                    Random rnd = new Random();
                    int chance = rnd.Next(1,100);
                    if ((chance % 2) == 0)
                      {  //first fighter attacks
                        w2.update_health(w1.Attack);
                        w1.comments();
                         }else 
                        {
                            w1.update_health(w2.Attack);
                            w2.comments();
                        }
                }
        if (w1.Health <= 0)
            Console.WriteLine ($"BATTLE OVER {w2.Name} WINS REMAINING HEALTH: {w2.Health} and {w1.Name} WITH HEALTH : {w1.Health}");
         else 
            Console.WriteLine($"BATTLE OVER {w1.Name} WINS WITH REMAINING HEALTH : {w1.Health} and {w2.Name} WITH HEALTH : {w2.Health}");   
        }

}


}