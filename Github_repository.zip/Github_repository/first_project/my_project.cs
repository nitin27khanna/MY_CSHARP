using Systems;
using Systems.Collections.Generic;
using Systems.Ling;
using Systems.Text;

namespace my_project {
    class Program
    {
     static void Main(String[] args)
     {
         Console.Writeline("Hellow WOrld!!");
     }
    }
}