﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace variable_practices{
class Program{
    public static void Main(string[] args)
    {
        int canIvote = 1;
        do{ 
        Console.WriteLine("Strongest Value: {0} ",int.MaxValue);    
        Console.WriteLine("Strongest Value: {0} ",int.MaxValue);
        Console.WriteLine("Enter can I vote : ");
        //canIvote = int(Console.ReadLine());
        canIvote +=1; 
        } while(canIvote != 4);
    Console.ReadLine();
    Console.WriteLine("Type of CanIvotr: {0} ", canIvote.GetType());
    //array of all the possible datatypes
    object[] randArray = {"Paul",45,'1',123.5};
    
    for (int i = 0 ; i < randArray.Length ; i++)
        Console.WriteLine("Type Of {0}th(rd,nd) object: {1}",i,randArray[i].GetType());
    
   // make double dimension arrays
   string[,] custname = new string[2,2]{{"Bob","Marley"},{"Was","Great"}};
   
   for (int i = 0 ; i < 2 ; i++)
        {
            Console.WriteLine();
        for (int j = 0 ; j < 2 ; j++)
                     Console.Write(custname.GetValue(i,j));
    
        }
    //more dynamic way to access arrays
    for (int i = 0 ; i < custname.GetLength(0);i++)
    {
            Console.WriteLine();
        for (int j = 0 ; j < custname.GetLength(1) ; j++)
                     Console.Write(custname.GetValue(i,j));
    
        }


            //foreach loop for array
            int [] randnums = {1,2,3,4,5};
            PrintArray(randnums,"Foreach");

            //array indexof function

            Console.WriteLine("Index of 3 in randnums : {0}",Array.IndexOf(randnums,3));
    }

     static void PrintArray(int[] intArray, string msg)
    {
        Console.WriteLine("\n {0}",msg);
        foreach(int k in intArray)
            Console.WriteLine("{0} ",k);
    }
}
}   