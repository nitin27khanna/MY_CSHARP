﻿//always start a program of console with this
using System;

//declare a namespace
namespace hellowworld
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            string v ;
            v =  Console.ReadLine();
            Console.WriteLine(v);

            /*Loops to print args array */
            for (int i = 0 ; i < args.Length ; i++)
            {
                Console.WriteLine ("Args{0} : {1}",i,args[i]);
            }
        

        //another way to take arguments
        string[] myArgs = Environment.GetCommandLineArgs()  ;
        Console.WriteLine(string.Join(", ",myArgs));

        sayhellow();
    }

    //functions 
    public static void sayhellow(){
        string name = "";
        Console.WriteLine("What is your name");
        name = Console.ReadLine();
        Console.WriteLine("Hellow {0}",name);
    } 
    }
    }