﻿using System;

namespace methodsbasics
{
    class Program
    {
        static void Main(string[] args)
        {
            Double d1,d2;
            d1 = 10;
            d2 = 10.1;
            ColorCars car1 = ColorCars.Red;
            paintcolor(car1); 
            Console.WriteLine("Sum of {0} , {1} : {2}",d1,d2,double_add(d1,d2));
            Console.WriteLine("D1 : {0} , D2 : {1}",d1,d2);
            //after swap
            Swap(ref d1 ,ref d2 );
            Console.WriteLine("After Swap D1 : {0} , D2 : {1}",d1,d2);
            
            PrintInfo(pin:10032, name:"NitinKhanna" );
            }
         public static double double_add(double d1=0  , double d2=0)
         {
             return d1+d2;
         }   
         public static void Swap(ref double a ,ref  double  b){
             a = a+b;
             b = a - b ;
             a = a - b ;
         }
         //parameters
         public static void PrintInfo(string name , int pin )
         {
             Console.WriteLine("{0} lives in city with pincode:= {1} ",name,pin);
         }
         
         //enums
         enum ColorCars : byte 
         {
             Orange = 1,
             Blue,
             Red,
             Pink
         }
        
         static void paintcolor(ColorCars cc)
        {
            Console.WriteLine("The Car was painted by {0} with the code {1}",cc ,(int)cc);
        }
    }
}
