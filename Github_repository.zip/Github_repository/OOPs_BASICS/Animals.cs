//class is defined in the same namespace

using System;

namespace OOPs_BASICS
{
class Animal
{
public string name;
public string voice;

//constructor
public Animal(){
    name = "";
    voice = "";
        numofanimals++;
}
public  Animal(string name = "No Name"){
    this.name = name;
    this.voice = "No Sound";
    numofanimals++;
}
public  Animal(string name = "No Name",string voice = "No Sound"){
    this.name = name;
    this.voice = voice;
        numofanimals++;
}
public void makesound(){
    Console.WriteLine("{0} makes {1} sound",this.name,this.voice);
}
static int numofanimals = 0;

public static int GetNumofAnimals(){
    return numofanimals;
}
}
}