﻿using System;

namespace OOPs_BASICS
{
    class Program
    {
        static void Main(string[] args)
        {
            Animal a1 = new Animal(){
                name = "Red",
                voice = "Raaw"
            };
            Console.WriteLine ("# of animals {0}",Animal.GetNumofAnimals());
            Rectangle r1 = new Rectangle(10,10);
            Rectangle r2 = new Rectangle(1.5,2);
            Console.WriteLine("Area Of Rectangle : {0}",r1.Area());
            
            Console.WriteLine("Area Of Rectangle : {0}",r2.Area());
        }
        //OOPS
        struct Rectangle
        {
            public double len;
            public double bre;

            //constructor
            public Rectangle(double d1=0 , double d2=0){
                len = d1;
                bre = d2;
            }

            public double Area()
            {
                return len * bre;
            }
        }
    }
}
